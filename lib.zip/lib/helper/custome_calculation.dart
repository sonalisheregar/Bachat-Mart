class Calculate{
  double getmargin( mrp, discount) {
    double difference = (mrp -discount);
    double profit = difference / mrp;
    print("???/" + mrp.toString() + "..." + discount.toString());
    return profit * 100;
  }
}