

class Features {
//Initialised as false, then assigned from get-restaurant api
  static bool isWebsiteSlider = false;
  static bool isCarousel = false;
  static bool isCategoryOne = false;
  static bool isAdsCategoryOne = false;
  static bool isBulkUpload = false;
  static bool isSellingItems = false;
  static bool isAdsItemsOne = false;
  static bool isCategoryTwo = false;
  static bool isAdsCategoryTwo = false;
  static bool isCategoryThree = false;
  static bool isVerticalSlider = false;
  static bool isFeatureAdsThree= false;
  static bool isCategory = false;
  static bool isBrands = false;
  static bool isDiscountItems = false;
  static bool isOfferItems = false;

  //Features
  static bool isLanguageModule = false; //done
  static bool isPickupfromStore = false; //done
  static bool isShoppingList = false; //done
  static bool isMembership = false; //done
  static bool isLoyalty = false; //done
  static bool isReferEarn = false; //done
  static bool isPromocode = false; //done
  static bool isPushNotification = false;
  static bool isOnBoarding = false; //done
  static bool isExpressDelivery = false; //done
  static bool isWallet = false; //done
  static bool isLiveChat = true; //done
  static bool isWhatsapp = false; //done
  static bool isFilter = false; //done
  static bool isShare = false; //done
  static bool isRepeatOrder = false;
  static bool isFooter = true;
  static bool isAnalytics = true;

  static bool isOffers = false; //done
  static bool isSubscription = false; //done
  static bool isReturnOrExchange = false; //done
  static bool isRefundModule = false; //done
  static bool isOffersForHomepage = false; //done
  static bool isRateOrderModule = false;
  static bool isSplit = false; //done
  static bool callMeInsteadOTP = false;
  static bool mainBanneraboveSlider = false;

  }

