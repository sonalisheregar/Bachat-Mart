
myObj get context => myObj();
class myObj {
  void operator []=(Object property, Object value){
  }
  dynamic callMethod(Object method, [List args]){
  }
}