import 'dart:convert';
import '../../models/newmodle/category_modle.dart';
import '../../models/newmodle/product_data.dart';
import '../../repository/api.dart';
import '../../utils/prefUtils.dart';

class ProductRepo {

Future<List<CategoryData>>  getCategory()async {
   var resp = json.decode(await api.Geturl(
      "restaurant/get-categories?branch=${PrefUtils.prefs.getString("branch") ??
          "999"}&language_id=${PrefUtils.prefs.getString("language_id") ??
          "0"}",isv2: false));
  if (resp["status"]) {
    List<CategoryData> caatdata;
   return CategoryDataModle.fromJson(resp).data/*.data.forEach((element) =>
        getSubcategory(element, (p0) {
          element.subCategory.addAll(p0);
          caatdata.add(element);
        }))*/;
    // return caatdata;
  }
}
getSubcategory(String catid,
      Function(List<CategoryData>) response) async {
    if(catid!=null) {
      var resp =
          await api.Geturl("restaurant/get-sub-category/${catid}");
      if (resp != "[]") {
        if (SubCatModle.fromJson(json.decode(resp)).status) {
         response( SubCatModle.fromJson(json.decode(resp)).data);
        } else {
          response(null);
        }
      } else {
        response(null);
      }
    }
    else{
      response(null);
    }
  }

  Future<List<ItemData>> getCartProductLists(categoryId, {start = 0, end = 0, type=0,}) async {
    api.body = {
      "id": categoryId,
      "start": start.toString(),
      "end": end.toString(),
      "branch": PrefUtils.prefs.getString("branch"),
      "user": PrefUtils.prefs.getString("apiKey") ?? "1",
      "language_id": "0",
      "type" : type.toString(),
    };
 final response = await api.Posturl("restaurant/get-menuitem-by-cart");
if((json.decode(response)["data"]).toString()=="[]")
  return null;
else
    return Future.value(ItemModle.fromJson(json.decode(response)).data);
  }
  Future<List<ItemData>> getBrandProductLists(categoryId, {start = 0, end = 0,}) async {
    api.body = {
      "id": categoryId,
      "start": start.toString(),
      "end": end.toString(),
      "branch": PrefUtils.prefs.getString("branch"),
      "user": PrefUtils.prefs.getString("apiKey") ?? "1",
      "language_id": "0"
    };
    final response = await api.Posturl("restaurant/get-menuitem-by-brand-by-cart");
    if((json.decode(response)["data"]).toString()=="[]")
      return null;
    else
    return Future.value(ItemModle
        .fromJson(json.decode(response))
        .data);
  }
  Future<List<ItemData>> getProduct(prodid) async {
    api.body = {
      'id': prodid,
      'branch': PrefUtils.prefs.getString("branch"),
      'user': PrefUtils.prefs.getString("apikey"),
      'language_id': '0'
    };
    return Future.value(ItemModle
        .fromJson(json.decode(await api.Posturl("single-product-by-cart")))
        .data);
  }
  Future<List<ItemData>> getSearchQuery(query) async {
    api.body = {
      'branch': PrefUtils.prefs.getString("branch"),
      'user': PrefUtils.prefs.containsKey("apikey")?PrefUtils.prefs.getString("apikey"):PrefUtils.prefs.getString("tokenid"),
      'language_id': '0',
      'item_name': '$query',
    };
  final resp =  await api.Posturl("restaurant/search-items-by-cart");
    return Future.value(ItemModle
        .fromJson(json.decode(resp))
        .data);
  }
  Future<ItemModle> getRecentProduct(prodid) async{
    return Future.value(ItemModle
        .fromJson(json.decode(await api.Posturl("restaurant/get-recent-products-by-cart/$prodid/${PrefUtils.prefs.containsKey("apikey")?PrefUtils.prefs.getString("apikey"):PrefUtils.prefs.getString("tokenid")}/${PrefUtils.prefs.getString("branch")}",isv2: false)))
        );
  }
}
class CategoryDataModle {
  bool status;
  List<CategoryData> data;

  CategoryDataModle({this.status, this.data});

  CategoryDataModle.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['data'] != null) {
      data = new List<CategoryData>();
      json['data'].forEach((v) {
        data.add(new CategoryData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    return data;
  }
}
class ItemModle {
  bool status;
  List<ItemData> data;

  ItemModle({this.status, this.data});

  ItemModle.fromJson(Map<String, dynamic> json) {
    status = json['status']??true;
    if (json['data'] != null) {
      data = new List<ItemData>();
      json['data'].forEach((v) {
        print("productdata::::"+v.toString());
        data.add(new ItemData.fromJson(v));
      });
      print(" data length${data.length}");
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    return data;
  }
}
class SubCatModle {
  bool status;
  List<CategoryData> data;

  SubCatModle({this.status, this.data});

  SubCatModle.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['data'] != null) {
      data = new List<CategoryData>();
      json['data'].forEach((v) {
        data.add(new CategoryData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    return data;
  }
}
