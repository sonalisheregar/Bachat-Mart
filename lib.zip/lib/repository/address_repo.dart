import 'dart:convert';

import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:grocbay/controller/mutations/address_mutation.dart';
import '../../models/newmodle/address.dart';
import '../../repository/api.dart';
import '../../utils/prefUtils.dart';

class AddressRepo{
  Future<List<Address>> getAddress()async{
   return AddressModle.fromJson(json.decode(await api.Geturl("get-address?customer=${PrefUtils.prefs.getString("apikey")??"1"}"))).data;
  }
  //Todo: Primery location
  Future<bool> addPrimeryLocation(LatLng latLng)async{
    api.body ={
      "id":PrefUtils.prefs.containsKey("apikey")?PrefUtils.prefs.getString("apikey"):PrefUtils.prefs.getString("tokenid"),
      "latitude":latLng.longitude.toString(),
      "longitude":latLng.longitude.toString(),
      "branch":PrefUtils.prefs.getString("branch")
    };

    if(json.decode(await api.Geturl("add-primary-location",isv2: false))["data"]){
      return true;
    }else{
      return false;
    }
  }
 Future<CurrentLocation> getcurentlocation(double latitude,double longitude,[address,area])async{
    final location =json.decode(await api.Geturl("check-location?lat=$latitude&long=$longitude",isv2: false));
    print("status rep: ${location["status"]}");
    return CurrentLocation(LatLng(latitude, longitude),address??location["area"],area??location["area"],location["status"]=="yes",location["branch"]);
  }
  Future<List<Address>> setDefultAddress({addressId,branch})async {
    if(json.decode(await api.Geturl("set-default-address?id=$addressId&branch=$branch"))["status"]==200) {
      print("value s");
      return await getAddress();
    } else null;
  }
  Future<List<Address>> removeAddress(body)async {
    api.body = body;
    if(json.decode(await api.Posturl("customer/address/remove"))["status"])
      return await getAddress();
    else null;
  }
  Future<List<Address>> addupdateAddress(Map<String, String>body)async {
    print("body....."+body.toString());
    api.body = body;
    var resp = await api.Posturl("customer/address/add-new");
    print("Result....."+resp.toString());
    bool result=json.decode(resp)["status"];
    if(result)
      return await getAddress();
    else null;
  }

}
class AddressList{
  List<Address> data;
  AddressList({
    this.data,
  });
  AddressList.fromJson(List<dynamic> json) {
    json.forEach((element) {
      data.add(Address.fromJson(element)) ;
    }) ;
  }
}